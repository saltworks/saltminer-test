# What are these files?

The paths.sh script will copy these files to the proper directories on the host filesystem.

These files require configuration before SaltMiner is started.
