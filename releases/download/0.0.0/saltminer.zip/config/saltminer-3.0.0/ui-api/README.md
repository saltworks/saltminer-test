This directory is used if SaltMiner is deployed with ELK cloud backend.

Note to Bryant: add more details.