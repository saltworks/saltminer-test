#!/bin/bash

# Copy latest config files from a SaltMiner artifact to the host filesystem.
# Requires that artifact unzipped to an artifacts directory

dist="./artifacts/dist"

smcfg="/etc/saltworks"
smcfg2="$smcfg"/saltminer-2.5.0
smcfg3="$smcfg"/saltminer-3.0.0

echo -e "\nCreating configuration files."

sudo mkdir -p $smcfg
sudo mkdir -p $smcfg2
sudo mkdir -p $smcfg3

sudo mkdir "$smcfg3"/agent
sudo mkdir "$smcfg3"/api
sudo mkdir "$smcfg3"/ui-api
sudo mkdir -p "$smcfg3"/jobmanager/report-templates

sudo cp -r ./config/saltminer-2.5.0/* "$smcfg2"/
sudo cp -r ./config/saltminer-3.0.0/agent/SourceConfigs/ "$smcfg3"/agent/
sudo cp ./config/saltminer-3.0.0/api/appsettings.json "$smcfg3"/api
sudo cp ./config/saltminer-3.0.0/ui-api/appsettings.json "$smcfg3"/ui-api
sudo cp -r ./config/saltminer-3.0.0/jobmanager/* "$smcfg3"/jobmanager/

sudo mkdir -p /etc/saltworks/saltminer/nginx

sudo cp ./nginx.conf /etc/saltworks/saltminer/nginx

echo -e "\nComplete.\n"
